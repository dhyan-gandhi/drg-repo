# -*- coding: utf-8 -*-
"""
Created on Sat Aug 24 00:58:37 2019
Par, Inc. nonlinear optimization using CVXOPT

@author: jg
"""

import numpy as np
from cvxopt import matrix
from cvxopt import solvers
# Define QP parameters (directly)
P = matrix(np.array([[2/15., 0.], [0., 2/5.]]),tc='d')
q = matrix(np.array([-80., -150.]).reshape((2,)), tc='d')    
G = matrix(np.array([[0.7, 1.], [0.5, 5/6.], [1., 2/3.], [0.1, 0.25]]), tc='d')
h = matrix(np.array([630., 600., 708., 135.]).reshape((4,)), tc='d')
# Construct the QP, invoke solver
#sol = solvers.qp(P,q,G,h)
sol = solvers.qp(P,q)
# Extract optimal value and solution
print(sol['x']) # [7.13e-07, 5.00e+00]
sol['primal objective'] # 20.0000061731