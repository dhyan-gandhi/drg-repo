# -*- coding: utf-8 -*-
"""
Created on Wed Jul 24 10:23:50 2018

Markowitz portfolio optimization. 

@author: jahan
"""


# Import the necessary packages
import numpy as np
from cvxopt import matrix
from cvxopt import solvers
import matplotlib.pyplot as plt



def calculate_MPT(returns,r_min):
    # calculation of P matrix in the quadratic equation 1/2 xt P x
    cov = np.matrix(np.cov(returns.T))
    # number of stocks or assessts
    N = returns.shape[1]
    # R-bar is the average returns from data. Would be compared to the minimum returns
    rbar = np.matrix(returns.mean(0))

    # define list of optimal / desired mus for which we'd like to find the optimal sigmas
    # This is the minimum returns plus accumulation of returns over 5 years. you can
    # also make all 5 years minimum returns equal to 10
    optimal_mus = []
    for i in range(N):
        optimal_mus.append(r_min)
        r_min += (rbar.mean() / 100)
    
    # calculate average minimum expected portfolio returns 
    mu = np.array(optimal_mus).mean()    

    # constraint matrices for quadratic programming. Here I used cvxopt package instead of quadprog that seems to be easier to use
    # parameters of cvxopt are similar to quadprog    
    P = matrix(cov)
    q = matrix(np.zeros((N, 1)))
    G = matrix(np.concatenate((-np.array(rbar), -np.identity(N)), 0))
    h = matrix(np.concatenate((-np.ones((1,1))*mu, np.zeros((N,1))),0))
    A = matrix(1.0, (1,N))
    b = matrix(1.0)
    
    # hide optimization
    solvers.options['show_progress'] = False
    
    # calculate portfolio weights, every weight vector is of size Nx1
    # find optimal weights with qp(P, q, G, h, A, b)
    optimal_weights = solvers.qp(P, q, G, h, A, b)
    w = optimal_weights['x']
    
    # find optimal sigma
    # \sigma = w^T * Cov * w
    #optimal_sigmas = [np.sqrt(np.matrix(w).T * cov.T.dot(np.matrix(w)))[0,0] for w in optimal_weights]
    optimal_sigma = np.sqrt(np.matrix(w).T * cov.T.dot(np.matrix(w)))
    
    return w, optimal_sigma.item(0), mu

# print optimum weights

def main():
    # define returns, returns are a matrix TxN. N is the number of assessts/stocks,
   # T number of years, time in time series

    returns = np.array([[10.06,17.64,32.41,32.36,33.44,24.56],
                        [13.12,3.25,18.71,20.61,19.40,25.32],
                        [13.47,7.51,33.28,12.93,3.85,-6.7],
                        [45.42,-1.33,41.46,7.06,58.68,5.43],
                        [-21.93,7.36,-23.26,-5.37,-9.02,17.31]])    
    minReturns = [8, 9, 10, 11, 12, 13, 14]
    mus = []
    optimal_sigmas = []
    w = []
    for i in range(len(minReturns)):
        weights, optimal_sig, mu =calculate_MPT(returns,minReturns[i])
        mus.append(mu)
        optimal_sigmas.append(optimal_sig)
        w.append(weights)
        print(weights)

    # plot Efficient Frontier
    plt.plot(optimal_sigmas, [x for x in minReturns],'y-o', color='orange', markersize=8, label='Efficient Frontier')  
    plt.xlabel('Expected Volatility (risk)')
    plt.ylabel('Expected Return')
    plt.title('Efficient Frontier')     

main()