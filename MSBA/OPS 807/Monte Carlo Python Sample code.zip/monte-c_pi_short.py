# -*- coding: utf-8 -*-
"""
Created on Sat Feb 24 11:33:24 2018

@author: jahan
"""

import numpy
N = 100000
inside = 0
for i in range(N):
    x = numpy.random.uniform(-1, 1)
    y = numpy.random.uniform(-1, 1)
    if numpy.sqrt(x**2 + y**2) < 1:
        inside += 1
print(4*inside/float(N))
