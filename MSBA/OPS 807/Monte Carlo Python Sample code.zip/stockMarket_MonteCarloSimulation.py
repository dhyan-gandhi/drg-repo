# -*- coding: utf-8 -*-
"""
Created on Sat Sep  7 06:09:09 2019

Monte Carlo Simulation for Stock price prediction

@author: jg
"""

import numpy
import scipy.stats
import matplotlib.pyplot as plt
from pandas import read_csv

plt.close('all')
# read stock historical data
MSFT = read_csv("MSFT.csv")

plt.figure()
MSFT.plot(y="Adj Close")
plt.title(u"Microsoft stock from 2009-2019", weight='bold');

# plot historical data/time series for MSFT 
fig = plt.figure()
fig.set_size_inches(10,3)
MSFT["Adj Close"].pct_change().plot()
plt.title("Microsoft stock daily returns from 2009-2019", weight='bold');

# plot histogram of the data
MSFT["Adj Close"].pct_change().hist(bins=15, normed=True, histtype='stepfilled', alpha=0.5)
plt.title("Histogram of Microsoft stock daily returns from 2009-2019", weight='bold')
MSFT["Adj Close"].pct_change().std()

"""
The quantile-quantile (q-q) plot is a graphical technique for determining if two data sets 
come from populations with a common distribution.
A q-q plot is a plot of the quantiles of the first data set against the quantiles of the second data set. 
By a quantile, we mean the fraction (or percent) of points below the given value. 
That is, the 0.3 (or 30%) quantile is the point at which 30% percent of the data 
fall below and 70% fall above that value.

A 45-degree reference line is also plotted. If the two sets come from 
a population with the same distribution, the points should fall approximately 
along this reference line. The greater the departure from this reference line, 
the greater the evidence for the conclusion that the two data sets have 
come from populations with different distributions.

"""
# QQ plot of MSFT with Gaussian/normal distribution
Q = MSFT["Adj Close"].pct_change().dropna().values
scipy.stats.probplot(Q, dist=scipy.stats.norm, plot=plt.figure().add_subplot(111))
plt.title("Normal QQ-plot of Microsoft daily returns from 2009-2019", weight="bold");

# QQ plot for MSFT and t-distribution
tdf, tmean, tsigma = scipy.stats.t.fit(Q)
scipy.stats.probplot(Q, dist=scipy.stats.t, sparams=(tdf, tmean, tsigma), plot=plt.figure().add_subplot(111))
plt.title(u"Student QQ-plot of Microsoft daily returns from 2009-2019", weight="bold")


"""
Value at Risk using the Monte Carlo method

# **Method**: run many trials with random market conditions, calculating portfolio loss for each trial. 
Use the aggregated trial data to establish a profile of the porfolio's risk characteristics. 

 
 **Hypothesis**: stock market evolution can be simulated by geometric Brownian motion 
(this is a rough hypothesis; see the literature on stochastic methods 
in finance for more sophisticated, and more realistic, models, such as jump diffusion).

We start by defining some parameters of the geometric Brownian motion.

"""
# This function simulates one stock market evolution, and returns the price evolution as an array. 
# It simulates geometric Brownian motion using random numbers drawn from 
# a normal distribution (see accompanying slides).

days = 300   # time horizon
dt = 1/float(days)
sigma = 0.04 # volatility
mu = 0.05  # drift (average growth rate)

def random_walk(startprice):
    price = numpy.zeros(days)
    shock = numpy.zeros(days)
    price[0] = startprice
    for i in range(1, days):
        shock[i] = numpy.random.normal(loc=mu * dt, scale=sigma * numpy.sqrt(dt))
        price[i] = max(0, price[i-1] + shock[i] * price[i-1])
    return price


# Let's simulate 30 random walks, starting from an initial stock price of 10€, 
# for a duration of 300 days.
for run in range(30):
    plt.plot(random_walk(10.0))
plt.xlabel("Time")
plt.ylabel("Price");


# Final price is spread out between 9.5$ (our portfolio has lost value) to almost 12$. 
#The expectation (mean outcome) is a profit; this is due to the fact that the drift in our random walk 
# (parameter mu) is positive.

# Now let's run a big Monte Carlo simulation of random walks of this type, 
# to obtain the probability distribution of the final price, and obtain quantile 
# measures for the Value at Risk estimation. 
# This will take a little time to run (decrease variable `runs` if you want faster, 
# but less representative, results).

# Monte Carlo Simulation of stock price changes 
runs = 10000
simulations = numpy.zeros(runs)
for run in range(runs):
    simulations[run] = random_walk(10.0)[days-1]
q = numpy.percentile(simulations, 1)

# plot the results
plt.figure()
plt.hist(simulations, normed=True, bins=30, histtype='stepfilled', alpha=0.5)
plt.figtext(0.6, 0.8, "Start price: 10$")
plt.figtext(0.6, 0.7, "Mean final price: {:.3}$".format(simulations.mean()))
plt.figtext(0.6, 0.6, "VaR(0.99): {:.3}$".format(10 - q))
plt.figtext(0.15, 0.6, "q(0.99): {:.3}$".format(q))
plt.axvline(x=q, linewidth=4, color='r')
plt.title("Final price distribution after {} days".format(days), weight='bold');


# We have looked at the 1% empirical quantile of the final price distribution 
# to estimate the Value at Risk, which is 0.427$ for a 10$ investment.
    
    




